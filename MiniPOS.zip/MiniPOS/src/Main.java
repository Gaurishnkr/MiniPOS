
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void open(Scanner sc) {

        ProductDAO productDAO = new ProductDAO();
        SalesDAO salesDAO = new SalesDAO();

        int branchId = 1;

        DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        boolean anotherCustomer = true;

        while (anotherCustomer) {

            // Load products from MariaDB
            ArrayList<Product> availableProducts =
                new ArrayList<>(productDAO.getProducts(branchId));

            if (availableProducts.isEmpty()) {
                System.out.println("No products available in database!");
                break;
            }

            ArrayList<Product> purchasedProducts = new ArrayList<>();
            ArrayList<Integer> purchasedQuantities = new ArrayList<>();
            ArrayList<String> receiptItems = new ArrayList<>();

            double grandTotal = 0;

            System.out.println("\n========== MINI POS ==========");
            System.out.println("NEW CUSTOMER BILL");

            // Display available products
            productDAO.viewProducts(branchId);

            // Product selection
            while (true) {

                int productId = readInt(sc, "\nEnter Product ID: ");

                int quantity = readInt(sc, "Enter Quantity: ");

                if (productId <= 0 || quantity <= 0) {
                    System.out.println(
                        "Product ID and quantity must be positive."
                    );
                    continue;
                }

                Product selectedProduct = null;

                // Find product
                for (Product product : availableProducts) {

                    if (product.getProductId() == productId) {
                        selectedProduct = product;
                        break;
                    }
                }

                if (selectedProduct == null) {

                    System.out.println("Invalid Product ID!");

                } else if (quantity > selectedProduct.getQuantity()) {

                    System.out.println(
                        "Insufficient stock! Available quantity: "
                            + selectedProduct.getQuantity()
                    );

                } else {

                    double total =
                        selectedProduct.calculateTotal(quantity);

                    if (total > 0) {

                        grandTotal += total;

                        purchasedProducts.add(selectedProduct);
                        purchasedQuantities.add(quantity);

                        String item = String.format(
                            "%-15s %5d %10.2f %10.2f",
                            selectedProduct.getProductName(),
                            quantity,
                            selectedProduct.getPrice(),
                            total
                        );

                        receiptItems.add(item);

                        System.out.println("Product added to bill!");
                    }
                }

                if (!readYesNo(sc, "\nAdd another product? (yes/no): ")) {
                    break;
                }
            }

            // Prevent empty bills
            if (purchasedProducts.isEmpty()) {

                System.out.println(
                    "\nNo products selected. Bill cancelled."
                );

                anotherCustomer = readYesNo(
                    sc,
                    "\nProcess another customer? (yes/no): "
                );

                continue;
            }

            // Discount
            double discountPercentage;

            while (true) {

                discountPercentage = readDouble(
                    sc,
                    "\nEnter discount percentage (0-100): "
                );

                if (discountPercentage >= 0 &&
                    discountPercentage <= 100) {

                    break;
                }

                System.out.println(
                    "Invalid discount percentage! Enter 0 to 100."
                );
            }

            double discountAmount =
                grandTotal * discountPercentage / 100;

            double taxableAmount =
                grandTotal - discountAmount;

            // GST
            double gstPercentage = 18;

            double gstAmount =
                taxableAmount * gstPercentage / 100;

            double finalTotal =
                taxableAmount + gstAmount;

            System.out.printf(
                "%nSubtotal: Rs %.2f%n", grandTotal
            );

            System.out.printf(
                "Discount: Rs %.2f%n", discountAmount
            );

            System.out.printf(
                "Taxable Amount: Rs %.2f%n", taxableAmount
            );

            System.out.printf(
                "GST (%.0f%%): Rs %.2f%n",
                gstPercentage,
                gstAmount
            );

            System.out.printf(
                "Final Total: Rs %.2f%n", finalTotal
            );

            // Payment
            double cashReceived;
            double balance;

            while (true) {

                cashReceived = readDouble(
                    sc,
                    "\nEnter cash received: Rs "
                );

                if (cashReceived >= finalTotal) {

                    balance = cashReceived - finalTotal;
                    break;

                } else {

                    System.out.println(
                        "Insufficient payment! Please enter enough cash."
                    );
                }
            }

            // Generate bill number
            String currentBillNumber =
                salesDAO.generateBillNumber();

            if (currentBillNumber == null) {

                System.out.println(
                    "Could not generate bill number. Bill cancelled."
                );

                break;
            }

            // Save complete bill to MariaDB
            boolean saved = salesDAO.saveSale(
                branchId,
                currentBillNumber,
                grandTotal,
                discountAmount,
                gstAmount,
                finalTotal,
                cashReceived,
                balance,
                purchasedProducts,
                purchasedQuantities
            );

            if (saved) {

                System.out.println(
                    "\nBill saved successfully in MariaDB!"
                );

                System.out.println(
                    "Payment completed successfully!"
                );

                // Print receipt
                LocalDateTime now = LocalDateTime.now();

                System.out.println(
                    "\n========== MINI POS RECEIPT =========="
                );

                System.out.println(
                    "Bill Number: " + currentBillNumber
                );

                System.out.println(
                    "Date & Time: " + now.format(formatter)
                );

                System.out.println(
                    "----------------------------------------------"
                );

                System.out.printf(
                    "%-15s %5s %10s %10s%n",
                    "Product", "Qty", "Price", "Amount"
                );

                System.out.println(
                    "----------------------------------------------"
                );

                for (String item : receiptItems) {
                    System.out.println(item);
                }

                System.out.println(
                    "----------------------------------------------"
                );

                System.out.printf(
                    "Subtotal: Rs %.2f%n", grandTotal
                );

                System.out.printf(
                    "Discount: %.2f%%%n", discountPercentage
                );

                System.out.printf(
                    "Discount Amount: Rs %.2f%n", discountAmount
                );

                System.out.printf(
                    "Taxable Amount: Rs %.2f%n", taxableAmount
                );

                System.out.printf(
                    "GST (%.0f%%): Rs %.2f%n",
                    gstPercentage,
                    gstAmount
                );

                System.out.printf(
                    "Final Total: Rs %.2f%n", finalTotal
                );

                System.out.printf(
                    "Cash Received: Rs %.2f%n", cashReceived
                );

                System.out.printf(
                    "Change Returned: Rs %.2f%n", balance
                );

                System.out.println(
                    "=============================================="
                );

                // Display updated database stock
                System.out.println("\n===== UPDATED STOCK =====");

                productDAO.viewProducts(branchId);

                // Display persistent sales history
                salesDAO.viewSalesHistory(branchId);

            } else {

                System.out.println("\nBill could not be saved!");

                System.out.println(
                    "Do not complete the sale. Verify the database first."
                );
            }

            anotherCustomer = readYesNo(
                sc,
                "\nProcess another customer? (yes/no): "
            );
        }

        // Display database-backed daily report
        salesDAO.viewDailySalesReport(branchId);

        System.out.println("\nPOS system closed.");
    }

    // ================= INPUT HELPERS =================

    private static int readInt(Scanner sc, String message) {

        while (true) {

            System.out.print(message);

            String input = sc.nextLine().trim();

            try {

                return Integer.parseInt(input);

            } catch (NumberFormatException e) {

                System.out.println(
                    "Invalid input! Please enter a whole number."
                );
            }
        }
    }

    private static double readDouble(
        Scanner sc,
        String message
    ) {

        while (true) {

            System.out.print(message);

            String input = sc.nextLine().trim();

            try {

                double value = Double.parseDouble(input);

                if (Double.isFinite(value) && value >= 0) {
                    return value;
                }

                System.out.println(
                    "Please enter a valid non-negative amount."
                );

            } catch (NumberFormatException e) {

                System.out.println(
                    "Invalid input! Please enter a valid number."
                );
            }
        }
    }

    private static boolean readYesNo(
        Scanner sc,
        String message
    ) {

        while (true) {

            System.out.print(message);

            String choice = sc.nextLine().trim();

            if (choice.equalsIgnoreCase("yes")) {
                return true;
            }

            if (choice.equalsIgnoreCase("no")) {
                return false;
            }

            System.out.println("Please enter yes or no.");
        }
    }
}
