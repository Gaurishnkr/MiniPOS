
import java.util.Scanner;

public class ProductManagementApp {

    public static void open(Scanner sc) {

        ProductDAO productDAO = new ProductDAO();

        int branchId = 1;
        int choice;

        do {
            System.out.println("\n========== PRODUCT MANAGEMENT ==========");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Update Stock");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Admin Dashboard");
            System.out.println("========================================");

            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {

                case 1:
                    System.out.print("Enter Product Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Selling Price: ");
                    double price = Double.parseDouble(sc.nextLine());

                    System.out.print("Enter Opening Stock: ");
                    int quantity = Integer.parseInt(sc.nextLine());

                    if (name.trim().isEmpty() || price <= 0 || quantity < 0) {
                        System.out.println("Invalid product details!");
                    } else if (productDAO.addProduct(branchId, name, price, quantity)) {
                        System.out.println("Product added successfully!");
                    } else {
                        System.out.println("Failed to add product!");
                    }
                    break;

                case 2:
                    productDAO.viewProducts(branchId);
                    break;

                case 3:
                    System.out.print("Enter Product ID: ");
                    int updateId = Integer.parseInt(sc.nextLine());

                    System.out.print("Enter New Stock Quantity: ");
                    int newQuantity = Integer.parseInt(sc.nextLine());

                    if (newQuantity < 0) {
                        System.out.println("Invalid stock quantity!");
                    } else if (productDAO.updateStock(updateId, branchId, newQuantity)) {
                        System.out.println("Stock updated successfully!");
                    } else {
                        System.out.println("Stock update failed!");
                    }
                    break;

                case 4:
                    System.out.print("Enter Product ID to delete: ");
                    int deleteId = Integer.parseInt(sc.nextLine());

                    System.out.print("Are you sure? (yes/no): ");
                    String confirmation = sc.nextLine();

                    if (confirmation.equalsIgnoreCase("yes")) {
                        if (productDAO.deleteProduct(deleteId, branchId)) {
                            System.out.println("Product deleted successfully!");
                        } else {
                            System.out.println("Product deletion failed!");
                        }
                    } else {
                        System.out.println("Deletion cancelled.");
                    }
                    break;

                case 5:
                    System.out.println("Returning to Admin Dashboard...");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 5);
    }
}
