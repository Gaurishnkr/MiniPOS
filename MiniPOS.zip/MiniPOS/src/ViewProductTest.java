public class ViewProductTest {

    public static void main(String[] args) {

        ProductDAO productDAO = new ProductDAO();

        // View products from Main Branch
        productDAO.viewProducts(1);
    }
}