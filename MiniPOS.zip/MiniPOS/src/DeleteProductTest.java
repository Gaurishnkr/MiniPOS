public class DeleteProductTest {

    public static void main(String[] args) {

        ProductDAO productDAO = new ProductDAO();

        // Delete product ID 2 from Main Branch
        boolean result = productDAO.deleteProduct(2, 1);

        if (result) {
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Product deletion failed!");
        }
    }
}