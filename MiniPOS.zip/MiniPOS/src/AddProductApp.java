import java.util.Scanner;

public class AddProductApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductDAO productDAO = new ProductDAO();

        System.out.println("====== ADD NEW PRODUCT ======");

        System.out.print("Enter Branch ID: ");
        int branchId = Integer.parseInt(sc.nextLine());

        System.out.print("Enter Product Name: ");
        String productName = sc.nextLine();

        System.out.print("Enter Selling Price: ");
        double price = Double.parseDouble(sc.nextLine());

        System.out.print("Enter Opening Stock: ");
        int quantity = Integer.parseInt(sc.nextLine());

        if (branchId <= 0 ||
            productName.trim().isEmpty() ||
            price <= 0 ||
            quantity < 0) {

            System.out.println("Invalid product details!");

        } else {

            boolean result = productDAO.addProduct(
                    branchId,
                    productName,
                    price,
                    quantity
            );

            if (result) {
                System.out.println("Product added successfully!");
            } else {
                System.out.println("Failed to add product!");
            }
        }

        sc.close();
    }
}
