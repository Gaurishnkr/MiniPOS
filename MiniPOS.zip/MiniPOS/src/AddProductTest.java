public class AddProductTest {

    public static void main(String[] args) {

        ProductDAO productDAO = new ProductDAO();

        boolean result = productDAO.addProduct(
                1,
                "Keyboard",
                900.00,
                10
        );

        if (result) {
            System.out.println("Product added successfully!");
        } else {
            System.out.println("Failed to add product!");
        }
    }
}