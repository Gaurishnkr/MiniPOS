
import java.util.Scanner;

public class UserManagementApp {

    public static void open(Scanner sc) {

        UserDAO userDAO = new UserDAO();
        int branchId = 1;
        int choice;

        do {
            System.out.println("\n========== USER MANAGEMENT ==========");
            System.out.println("1. Create Cashier Account");
            System.out.println("2. View Users");
            System.out.println("3. Back to Admin Dashboard");
            System.out.println("=====================================");

            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {

                case 1:
                    System.out.print("Enter Cashier Username: ");
                    String username = sc.nextLine().trim();

                    if (username.isEmpty()) {
                        System.out.println("Username cannot be empty!");
                        break;
                    }

                    if (userDAO.usernameExists(username)) {
                        System.out.println("Username already exists!");
                        break;
                    }

                    System.out.print("Enter Password: ");
                    String password = sc.nextLine();

                    System.out.print("Confirm Password: ");
                    String confirmPassword = sc.nextLine();

                    if (password.length() < 4) {
                        System.out.println("Password must contain at least 4 characters.");
                    } else if (!password.equals(confirmPassword)) {
                        System.out.println("Passwords do not match!");
                    } else if (userDAO.createUser(
                            branchId, username, password, "CASHIER")) {
                        System.out.println("Cashier account created successfully!");
                    } else {
                        System.out.println("Unable to create cashier account.");
                    }
                    break;

                case 2:
                    userDAO.viewUsers(branchId);
                    break;

                case 3:
                    System.out.println("Returning to Admin Dashboard...");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 3);
    }
}
