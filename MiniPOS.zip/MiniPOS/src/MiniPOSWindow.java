import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MiniPOSWindow {

    private static JFrame frame;
    private static UserDAO userDAO = new UserDAO();

    private static String currentUsername = "";
    private static String currentRole = "";

// ================= PROFESSIONAL UI THEME =================

private static final Color NAVY = new Color(25, 35, 58);
private static final Color BLUE = new Color(45, 110, 220);
private static final Color BACKGROUND = new Color(245, 247, 251);
private static final Color WHITE = Color.WHITE;
private static final Color TEXT = new Color(45, 55, 72);
private static final Color MUTED = new Color(120, 130, 145);

private static void applyTheme() {

    UIManager.put("Panel.background", BACKGROUND);
    UIManager.put("OptionPane.background", WHITE);
    UIManager.put("OptionPane.messageFont",
            new Font("Segoe UI", Font.PLAIN, 14));

    UIManager.put("Button.font",
            new Font("Segoe UI", Font.BOLD, 13));
    UIManager.put("Button.background", BLUE);
    UIManager.put("Button.foreground", WHITE);
    UIManager.put("Button.focus", new Color(0, 0, 0, 0));

    UIManager.put("Label.font",
            new Font("Segoe UI", Font.PLAIN, 14));
    UIManager.put("TextField.font",
            new Font("Segoe UI", Font.PLAIN, 14));
    UIManager.put("PasswordField.font",
            new Font("Segoe UI", Font.PLAIN, 14));

    UIManager.put("Table.font",
            new Font("Segoe UI", Font.PLAIN, 13));
    UIManager.put("Table.rowHeight", 30);
    UIManager.put("TableHeader.font",
            new Font("Segoe UI", Font.BOLD, 13));
    UIManager.put("TableHeader.background", NAVY);
    UIManager.put("TableHeader.foreground", WHITE);
    UIManager.put("Table.selectionBackground",
            new Color(220, 235, 255));
    UIManager.put("Table.selectionForeground", TEXT);
}

private static void styleButton(JButton button) {

    button.setFont(new Font("Segoe UI", Font.BOLD, 13));
    button.setBackground(BLUE);
    button.setForeground(WHITE);
    button.setFocusPainted(false);
    button.setBorder(
            BorderFactory.createEmptyBorder(10, 18, 10, 18)
    );
    button.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
    );
}

private static void styleTable(JTable table) {

    table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    table.setRowHeight(32);
    table.setShowGrid(false);
    table.setIntercellSpacing(new Dimension(0, 1));
    table.setSelectionBackground(new Color(220, 235, 255));
    table.setSelectionForeground(TEXT);

    table.getTableHeader().setFont(
            new Font("Segoe UI", Font.BOLD, 13)
    );
    table.getTableHeader().setBackground(NAVY);
    table.getTableHeader().setForeground(WHITE);
    table.getTableHeader().setPreferredSize(
            new Dimension(0, 38)
    );
}


    public static void main(String[] args) {
        
        applyTheme();

        SwingUtilities.invokeLater(MiniPOSWindow::showLogin);
    }

    // ================= LOGIN =================

    private static void showLogin() {

    frame = new JFrame("MiniPOS | Point of Sale");
    frame.setSize(950, 600);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);

    JPanel mainPanel = new JPanel(new GridLayout(1, 2));
    mainPanel.setBackground(BACKGROUND);

    // Left branding section
    JPanel leftPanel = new JPanel();
    leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
    leftPanel.setBackground(NAVY);
    leftPanel.setBorder(
            BorderFactory.createEmptyBorder(130, 45, 50, 35)
    );

    JLabel brand = new JLabel("MINIPOS");
    brand.setFont(new Font("Segoe UI", Font.BOLD, 38));
    brand.setForeground(WHITE);

    JLabel description = new JLabel(
            "<html>Smart and simple<br>Point of Sale Management</html>"
    );
    description.setFont(new Font("Segoe UI", Font.PLAIN, 17));
    description.setForeground(new Color(200, 210, 230));

    leftPanel.add(brand);
    leftPanel.add(Box.createVerticalStrut(20));
    leftPanel.add(description);

    // Right login section
    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
    rightPanel.setBackground(WHITE);
    rightPanel.setBorder(
            BorderFactory.createEmptyBorder(115, 65, 80, 65)
    );

    JLabel welcome = new JLabel("Welcome Back");
    welcome.setFont(new Font("Segoe UI", Font.BOLD, 28));
    welcome.setForeground(TEXT);
    welcome.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitle = new JLabel("Login to access your account");
    subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    subtitle.setForeground(MUTED);
    subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

    JButton loginButton = new JButton("LOGIN");
    styleButton(loginButton);
    loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
    loginButton.setMaximumSize(new Dimension(300, 45));

    JButton exitButton = new JButton("Exit Application");
    exitButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    exitButton.setForeground(MUTED);
    exitButton.setContentAreaFilled(false);
    exitButton.setBorderPainted(false);
    exitButton.setAlignmentX(Component.LEFT_ALIGNMENT);

    rightPanel.add(welcome);
    rightPanel.add(Box.createVerticalStrut(12));
    rightPanel.add(subtitle);
    rightPanel.add(Box.createVerticalStrut(40));
    rightPanel.add(loginButton);
    rightPanel.add(Box.createVerticalStrut(15));
    rightPanel.add(exitButton);

    mainPanel.add(leftPanel);
    mainPanel.add(rightPanel);

    loginButton.addActionListener(e -> login());
    exitButton.addActionListener(e -> System.exit(0));

    frame.setContentPane(mainPanel);
    frame.setVisible(true);
}

    private static void login() {

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        int result = JOptionPane.showConfirmDialog(
            frame,
            panel,
            "MiniPOS Login",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (userDAO.authenticate(username, password)) {

            String role = userDAO.getUserRole(username);

            currentUsername = username;
            currentRole = role;

            if ("ADMIN".equalsIgnoreCase(role)) {
                showAdminDashboard(username);

            } else if ("CASHIER".equalsIgnoreCase(role)) {
                showCashierDashboard(username);

            } else {
                JOptionPane.showMessageDialog(
                    frame,
                    "Invalid user role!"
                );
            }

        } else {
            JOptionPane.showMessageDialog(
                frame,
                "Invalid username or password!"
            );
        }
    }

    // ================= ADMIN DASHBOARD =================

    private static void showAdminDashboard(String username) {

    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.setBackground(BACKGROUND);

    // LEFT SIDEBAR
    JPanel sidebar = new JPanel();
    sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
    sidebar.setBackground(NAVY);
    sidebar.setPreferredSize(new Dimension(220, 0));
    sidebar.setBorder(
            BorderFactory.createEmptyBorder(25, 15, 20, 15)
    );

    JLabel logo = new JLabel("MINIPOS");
    logo.setFont(new Font("Segoe UI", Font.BOLD, 25));
    logo.setForeground(WHITE);
    logo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel adminLabel = new JLabel("ADMIN PANEL");
    adminLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
    adminLabel.setForeground(new Color(170, 185, 210));
    adminLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

    sidebar.add(logo);
    sidebar.add(Box.createVerticalStrut(8));
    sidebar.add(adminLabel);
    sidebar.add(Box.createVerticalStrut(45));

    JButton products = new JButton("Manage Products");
    JButton stock = new JButton("Manage Stock");
    JButton users = new JButton("Manage Users");
    JButton history = new JButton("Sales History");
    JButton reports = new JButton("Sales Reports");
    JButton logout = new JButton("Logout");

    JButton[] menuButtons = {
        products, stock, users, history, reports, logout
    };

    for (JButton button : menuButtons) {
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(190, 42));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBackground(NAVY);
        button.setForeground(WHITE);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        button.setFocusPainted(false);
        button.setBorder(
                BorderFactory.createEmptyBorder(10, 12, 10, 8)
        );
        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(8));
    }

    Component verticalSpace = Box.createVerticalGlue();
    sidebar.add(verticalSpace);

    // MAIN CONTENT
    JPanel content = new JPanel(new BorderLayout(20, 20));
    content.setBackground(BACKGROUND);
    content.setBorder(
            BorderFactory.createEmptyBorder(30, 35, 30, 35)
    );

    JPanel header = new JPanel(new BorderLayout());
    header.setOpaque(false);

    JLabel title = new JLabel("Dashboard");
    title.setFont(new Font("Segoe UI", Font.BOLD, 28));
    title.setForeground(TEXT);

    JLabel welcome = new JLabel("Welcome, " + username);
    welcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    welcome.setForeground(MUTED);

    JPanel heading = new JPanel();
    heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
    heading.setOpaque(false);
    heading.add(title);
    heading.add(Box.createVerticalStrut(6));
    heading.add(welcome);

    header.add(heading, BorderLayout.WEST);

    JPanel infoPanel = new JPanel(new GridLayout(1, 2, 18, 18));
    infoPanel.setOpaque(false);

    JLabel productsInfo = new JLabel(
            "<html><b>PRODUCT MANAGEMENT</b><br><br>" +
            "Add products, update prices and manage stock.</html>"
    );

    JLabel salesInfo = new JLabel(
            "<html><b>SALES MANAGEMENT</b><br><br>" +
            "View bills and monitor your sales performance.</html>"
    );

    for (JLabel label : new JLabel[]{productsInfo, salesInfo}) {
        label.setOpaque(true);
        label.setBackground(WHITE);
        label.setForeground(TEXT);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        label.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(230, 233, 240)
                        ),
                        BorderFactory.createEmptyBorder(
                                25, 20, 25, 20
                        )
                )
        );
    }

    infoPanel.add(productsInfo);
    infoPanel.add(salesInfo);

    JLabel footer = new JLabel("MiniPOS  |  Point of Sale Management System");
    footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    footer.setForeground(MUTED);

    content.add(header, BorderLayout.NORTH);
    content.add(infoPanel, BorderLayout.CENTER);
    content.add(footer, BorderLayout.SOUTH);

    // BUTTON ACTIONS
    products.addActionListener(e -> showProductManagement());
    stock.addActionListener(e -> showComingSoon("Stock Management"));
    users.addActionListener(e -> showComingSoon("User Management"));
    history.addActionListener(e -> showSalesHistory());
    reports.addActionListener(e -> showSalesReports());
    logout.addActionListener(e -> showLogin());

    mainPanel.add(sidebar, BorderLayout.WEST);
    mainPanel.add(content, BorderLayout.CENTER);

    frame.setContentPane(mainPanel);
    frame.setTitle("MiniPOS - Admin Dashboard");
    frame.setSize(1050, 650);
    frame.setMinimumSize(new Dimension(850, 550));
    frame.setLocationRelativeTo(null);
    frame.revalidate();
    frame.repaint();
}

    // ================= PRODUCT MANAGEMENT =================

    private static void showProductManagement() {

        ProductDAO productDAO = new ProductDAO();

        List<Product> products = productDAO.getProducts(1);

        String[] columns = {
            "Product ID",
            "Product Name",
            "Price",
            "Stock"
        };

        DefaultTableModel model =
            new DefaultTableModel(columns, 0) {

                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

        for (Product product : products) {

            model.addRow(new Object[]{
                product.getProductId(),
                product.getProductName(),
                product.getPrice(),
                product.getQuantity()
            });
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JButton addButton = new JButton("Add Product");
        JButton updateStockButton = new JButton("Update Stock");
        JButton deleteButton = new JButton("Delete Product");
        JButton backButton = new JButton("Back to Dashboard");

        JLabel title = new JLabel(
            "PRODUCT MANAGEMENT",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 22));

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JPanel buttonPanel = new JPanel();

        buttonPanel.add(addButton);
        buttonPanel.add(updateStockButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);

        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addProduct());

        updateStockButton.addActionListener(
            e -> updateStock()
        );

        deleteButton.addActionListener(
            e -> deleteProduct()
        );

        backButton.addActionListener(
            e -> showAdminDashboard(currentUsername)
        );

        frame.setContentPane(panel);
        frame.setTitle("MiniPOS - Product Management");
        frame.setSize(850, 500);
        frame.setLocationRelativeTo(null);
        frame.revalidate();
        frame.repaint();
    }

// ================= CASHIER DASHBOARD =================

private static void showCashierDashboard(String username) {

    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.setBackground(BACKGROUND);

    // Header
    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(NAVY);
    header.setBorder(
        BorderFactory.createEmptyBorder(20, 25, 20, 25)
    );

    JLabel title = new JLabel("MINIPOS");
    title.setFont(new Font("Segoe UI", Font.BOLD, 25));
    title.setForeground(WHITE);

    JLabel welcome = new JLabel("Welcome, " + username);
    welcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    welcome.setForeground(WHITE);

    header.add(title, BorderLayout.WEST);
    header.add(welcome, BorderLayout.EAST);

    // Main buttons
    JPanel buttonPanel = new JPanel(
        new GridLayout(1, 2, 20, 20)
    );
    buttonPanel.setBackground(BACKGROUND);
    buttonPanel.setBorder(
        BorderFactory.createEmptyBorder(100, 80, 100, 80)
    );

    JButton billingButton = new JButton("Create Bill");
    JButton historyButton = new JButton("Sales History");

    styleButton(billingButton);
    styleButton(historyButton);

    billingButton.addActionListener(
        e -> showBillingScreen()
    );

    historyButton.addActionListener(
        e -> showSalesHistory()
    );

    buttonPanel.add(billingButton);
    buttonPanel.add(historyButton);

    // Logout
    JButton logoutButton = new JButton("Logout");
    styleButton(logoutButton);

    JPanel footer = new JPanel(
        new FlowLayout(FlowLayout.RIGHT)
    );
    footer.setBackground(BACKGROUND);
    footer.add(logoutButton);

    logoutButton.addActionListener(e -> showLogin());

    mainPanel.add(header, BorderLayout.NORTH);
    mainPanel.add(buttonPanel, BorderLayout.CENTER);
    mainPanel.add(footer, BorderLayout.SOUTH);

    frame.setContentPane(mainPanel);
    frame.setTitle("MiniPOS - Cashier Dashboard");
    frame.setSize(950, 600);
    frame.setLocationRelativeTo(null);
    frame.revalidate();
    frame.repaint();
}


    // ================= ADD PRODUCT =================

    private static void addProduct() {

        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField quantityField = new JTextField();

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));

        form.add(new JLabel("Product Name:"));
        form.add(nameField);

        form.add(new JLabel("Price:"));
        form.add(priceField);

        form.add(new JLabel("Stock Quantity:"));
        form.add(quantityField);

        int result = JOptionPane.showConfirmDialog(
            frame,
            form,
            "Add New Product",
            JOptionPane.OK_CANCEL_OPTION
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        try {

            String name = nameField.getText().trim();

            double price = Double.parseDouble(
                priceField.getText().trim()
            );

            int quantity = Integer.parseInt(
                quantityField.getText().trim()
            );

            if (name.isEmpty() || price <= 0 || quantity < 0) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Enter a valid name, positive price and non-negative stock."
                );

                return;
            }

            ProductDAO productDAO = new ProductDAO();

            boolean success = productDAO.addProduct(
                1,
                name,
                price,
                quantity
            );

            if (success) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Product added successfully!"
                );

                showProductManagement();

            } else {

                JOptionPane.showMessageDialog(
                    frame,
                    "Unable to add product."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                frame,
                "Price and quantity must be valid numbers."
            );
        }
    }

    // ================= UPDATE STOCK =================

    private static void updateStock() {

        String productIdInput = JOptionPane.showInputDialog(
            frame,
            "Enter Product ID:"
        );

        if (productIdInput == null) {
            return;
        }

        String quantityInput = JOptionPane.showInputDialog(
            frame,
            "Enter new stock quantity:"
        );

        if (quantityInput == null) {
            return;
        }

        try {

            int productId = Integer.parseInt(
                productIdInput.trim()
            );

            int quantity = Integer.parseInt(
                quantityInput.trim()
            );

            if (productId <= 0 || quantity < 0) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Enter a valid Product ID and non-negative quantity."
                );

                return;
            }

            ProductDAO productDAO = new ProductDAO();

            boolean success = productDAO.updateStock(
                productId,
                1,
                quantity
            );

            if (success) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Stock updated successfully!"
                );

                showProductManagement();

            } else {

                JOptionPane.showMessageDialog(
                    frame,
                    "Unable to update stock. Check the Product ID."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                frame,
                "Product ID and quantity must be numbers."
            );
        }
    }

    // ================= DELETE PRODUCT =================

    private static void deleteProduct() {

        String input = JOptionPane.showInputDialog(
            frame,
            "Enter Product ID to delete:"
        );

        if (input == null) {
            return;
        }

        try {

            int productId = Integer.parseInt(input.trim());

            if (productId <= 0) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Invalid Product ID."
                );

                return;
            }

            int confirmation = JOptionPane.showConfirmDialog(
                frame,
                "Are you sure you want to delete Product ID "
                    + productId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );

            if (confirmation != JOptionPane.YES_OPTION) {
                return;
            }

            ProductDAO productDAO = new ProductDAO();

            boolean success = productDAO.deleteProduct(
                productId,
                1
            );

            if (success) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Product deleted successfully!"
                );

                showProductManagement();

            } else {

                JOptionPane.showMessageDialog(
                    frame,
                    "Unable to delete product. Check the Product ID."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                frame,
                "Product ID must be a number."
            );
        }
    }

    // ================= BILLING SCREEN =================

    private static void showBillingScreen() {

        ProductDAO productDAO = new ProductDAO();
        SalesDAO salesDAO = new SalesDAO();

        List<Product> products = productDAO.getProducts(1);

        String[] columns = {
            "Product ID",
            "Product Name",
            "Price",
            "Stock",
            "Quantity"
        };

        DefaultTableModel model =
            new DefaultTableModel(columns, 0) {

                @Override
                public boolean isCellEditable(int row, int column) {
                    return column == 4;
                }
            };

        for (Product product : products) {

            model.addRow(new Object[]{
                product.getProductId(),
                product.getProductName(),
                product.getPrice(),
                product.getQuantity(),
                0
            });
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JLabel title = new JLabel(
            "CREATE BILL",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 24));

        JButton calculateButton =
            new JButton("Calculate & Save Bill");

        JButton backButton =
            new JButton("Back to Dashboard");

        JPanel buttons = new JPanel();

        buttons.add(calculateButton);
        buttons.add(backButton);

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        panel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);

        calculateButton.addActionListener(e -> {

            // Finish editing the current table cell.
            if (table.isEditing()) {
                table.getCellEditor().stopCellEditing();
            }

            List<Product> selectedProducts =
                new ArrayList<>();

            List<Integer> quantities =
                new ArrayList<>();

            double subtotal = 0;

            try {

                for (int i = 0; i < model.getRowCount(); i++) {

                    int quantity = Integer.parseInt(
                        model.getValueAt(i, 4).toString()
                    );

                    int stock = Integer.parseInt(
                        model.getValueAt(i, 3).toString()
                    );

                    double price = Double.parseDouble(
                        model.getValueAt(i, 2).toString()
                    );

                    if (quantity < 0 || quantity > stock) {

                        JOptionPane.showMessageDialog(
                            frame,
                            "Invalid quantity for "
                                + model.getValueAt(i, 1)
                        );

                        return;
                    }

                    if (quantity > 0) {

                        int productId = Integer.parseInt(
                            model.getValueAt(i, 0).toString()
                        );

                        String productName =
                            model.getValueAt(i, 1).toString();

                        Product selectedProduct = new Product(
                            productId,
                            productName,
                            price,
                            stock
                        );

                        selectedProducts.add(selectedProduct);
                        quantities.add(quantity);

                        subtotal += price * quantity;
                    }
                }

                if (selectedProducts.isEmpty()) {

                    JOptionPane.showMessageDialog(
                        frame,
                        "Please select at least one product."
                    );

                    return;
                }

                double discount = 0;
                double gst = subtotal * 0.18;
                double finalTotal = subtotal + gst;

                String cashInput = JOptionPane.showInputDialog(
                    frame,
                    String.format(
                        "Subtotal: Rs %.2f\n" +
                        "GST (18%%): Rs %.2f\n" +
                        "Final Total: Rs %.2f\n\n" +
                        "Enter cash received:",
                        subtotal,
                        gst,
                        finalTotal
                    )
                );

                if (cashInput == null) {
                    return;
                }

                double cashReceived = Double.parseDouble(
                    cashInput.trim()
                );

                if (cashReceived < finalTotal) {

                    JOptionPane.showMessageDialog(
                        frame,
                        "Insufficient cash received!"
                    );

                    return;
                }

                if (cashReceived < 0) {

                    JOptionPane.showMessageDialog(
                        frame,
                        "Cash received cannot be negative."
                    );

                    return;
                }

                double changeReturned =
                    cashReceived - finalTotal;

                String billNumber =
                    salesDAO.generateBillNumber();

                if (billNumber == null) {

                    JOptionPane.showMessageDialog(
                        frame,
                        "Could not generate bill number."
                    );

                    return;
                }

                boolean saved = salesDAO.saveSale(
                    1,
                    billNumber,
                    subtotal,
                    discount,
                    gst,
                    finalTotal,
                    cashReceived,
                    changeReturned,
                    selectedProducts,
                    quantities
                );

                if (saved) {

                    JOptionPane.showMessageDialog(
                        frame,
                        String.format(
                            "BILL SAVED SUCCESSFULLY!\n\n" +
                            "Bill Number: %s\n" +
                            "Subtotal: Rs %.2f\n" +
                            "Discount: Rs %.2f\n" +
                            "GST: Rs %.2f\n" +
                            "Final Total: Rs %.2f\n" +
                            "Cash Received: Rs %.2f\n" +
                            "Change Returned: Rs %.2f",
                            billNumber,
                            subtotal,
                            discount,
                            gst,
                            finalTotal,
                            cashReceived,
                            changeReturned
                        )
                    );
int printChoice = JOptionPane.showConfirmDialog(
        frame,
        "Would you like to print this bill?",
        "Print Invoice",
        JOptionPane.YES_NO_OPTION
);

if (printChoice == JOptionPane.YES_OPTION) {
    printBill(
            billNumber,
            selectedProducts,
            quantities,
            subtotal,
            discount,
            gst,
            finalTotal,
            cashReceived,
            changeReturned
    );
}
                    // Reload products with updated stock.
                    showBillingScreen();

                } else {

                    JOptionPane.showMessageDialog(
                        frame,
                        "Bill could not be saved. Check stock and database."
                    );
                }

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                    frame,
                    "Enter valid whole-number quantities and a valid cash amount."
                );
            }
        });

        backButton.addActionListener(
            e -> showCashierDashboard(currentUsername)
        );

        frame.setContentPane(panel);
        frame.setTitle("MiniPOS - Billing");
        frame.setSize(900, 550);
        frame.setLocationRelativeTo(null);
        frame.revalidate();
        frame.repaint();
    }


    // ================= PRINT BILL =================

// ================= PRINT PROFESSIONAL BILL =================

private static void printBill(
        String billNumber,
        List<Product> products,
        List<Integer> quantities,
        double subtotal,
        double discount,
        double gst,
        double finalTotal,
        double cashReceived,
        double changeReturned) {

    StringBuilder bill = new StringBuilder();

    String dateTime = java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter
            .ofPattern("dd-MM-yyyy HH:mm:ss"));

    bill.append("========================================\n");
    bill.append("GAVNI'S MINI POS\n");
    bill.append("CUSTOMER INVOICE\n");
    bill.append("========================================\n");

    bill.append("Bill No: ").append(billNumber).append("\n");
    bill.append("Date: ").append(dateTime).append("\n");

    bill.append("----------------------------------------\n");
    bill.append(String.format("%-16s %4s %8s\n",
            "Product", "Qty", "Total"));
    bill.append("----------------------------------------\n");

    for (int i = 0; i < products.size(); i++) {

        Product product = products.get(i);
        int quantity = quantities.get(i);

        double total = product.getPrice() * quantity;

        bill.append(String.format("%-16.16s %4d %8.2f\n",
                product.getProductName(),
                quantity,
                total));
    }

    bill.append("----------------------------------------\n");

    bill.append(String.format("Subtotal:             Rs %.2f\n", subtotal));
    bill.append(String.format("Discount:             Rs %.2f\n", discount));
    bill.append(String.format("GST:                  Rs %.2f\n", gst));

    bill.append("========================================\n");
    bill.append(String.format("GRAND TOTAL:          Rs %.2f\n", finalTotal));
    bill.append("========================================\n");

    bill.append(String.format("Cash Received:        Rs %.2f\n", cashReceived));
    bill.append(String.format("Change Returned:      Rs %.2f\n", changeReturned));

    bill.append("========================================\n");
    bill.append("          THANK YOU FOR SHOPPING!\n");
    bill.append("========================================\n");

    JTextArea receipt = new JTextArea(bill.toString());
    receipt.setFont(new Font("Monospaced", Font.PLAIN, 12));
    receipt.setEditable(false);

    try {
        receipt.print();
    } catch (java.awt.print.PrinterException ex) {

        JOptionPane.showMessageDialog(
                frame,
                "Printing failed: " + ex.getMessage());
    }
}


    // ================= SALES HISTORY =================

    private static void showSalesHistory() {

        String[] columns = {
            "Sale ID",
            "Bill Number",
            "Final Total",
            "Sale Date"
        };

        DefaultTableModel model =
            new DefaultTableModel(columns, 0) {

                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

        String sql = """
            SELECT sale_id, bill_number, final_total, sale_date
            FROM sales
            WHERE branch_id = ?
            ORDER BY sale_id DESC
            """;

        try (
            Connection connection =
                DatabaseConnection.getConnection();

            PreparedStatement statement =
                connection.prepareStatement(sql)
        ) {

            statement.setInt(1, 1);

            try (ResultSet rs = statement.executeQuery()) {

                while (rs.next()) {

                    model.addRow(new Object[]{
                        rs.getInt("sale_id"),
                        rs.getString("bill_number"),
                        rs.getDouble("final_total"),
                        rs.getTimestamp("sale_date")
                    });
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                frame,
                "Unable to load sales history: " + ex.getMessage()
            );

            return;
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JLabel title = new JLabel(
            "SALES HISTORY",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 24));

        JButton backButton =
            new JButton("Back to Dashboard");

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        panel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        backButton.addActionListener(e -> {

            if ("ADMIN".equalsIgnoreCase(currentRole)) {
                showAdminDashboard(currentUsername);
            } else {
                showCashierDashboard(currentUsername);
            }
        });

        frame.setContentPane(panel);
        frame.setTitle("MiniPOS - Sales History");
        frame.setSize(900, 550);
        frame.setLocationRelativeTo(null);
        frame.revalidate();
        frame.repaint();
    }

    // ================= COMING SOON =================

    // ================= SALES REPORTS =================

    
    // ================= SALES REPORTS =================

    private static void showSalesReports() {

        String sql = """
            SELECT
                COUNT(*) AS total_bills,
                COALESCE(SUM(final_total), 0) AS total_revenue
            FROM sales
            WHERE branch_id = ?
            """;

        try (
            Connection connection =
                DatabaseConnection.getConnection();

            PreparedStatement statement =
                connection.prepareStatement(sql)
        ) {

            statement.setInt(1, 1);

            try (ResultSet rs = statement.executeQuery()) {

                if (rs.next()) {

                    int totalBills = rs.getInt("total_bills");
                    double totalRevenue =
                        rs.getDouble("total_revenue");

                    JPanel details = new JPanel(
                        new GridLayout(2, 1, 15, 15)
                    );

                    details.setBorder(
                        BorderFactory.createEmptyBorder(
                            50, 100, 50, 100
                        )
                    );

                    JLabel billsLabel = new JLabel(
                        "Total Bills: " + totalBills,
                        SwingConstants.CENTER
                    );

                    JLabel revenueLabel = new JLabel(
                        String.format(
                            "Total Revenue: Rs %.2f",
                            totalRevenue
                        ),
                        SwingConstants.CENTER
                    );

                    billsLabel.setFont(
                        new Font("Arial", Font.BOLD, 20)
                    );

                    revenueLabel.setFont(
                        new Font("Arial", Font.BOLD, 20)
                    );

                    details.add(billsLabel);
                    details.add(revenueLabel);

                    JLabel title = new JLabel(
                        "SALES SUMMARY - ALL BILLS",
                        SwingConstants.CENTER
                    );

                    title.setFont(
                        new Font("Arial", Font.BOLD, 24)
                    );

                    JButton dateReportButton =
                        new JButton("Date-wise Report");

                    dateReportButton.addActionListener(
                        e -> showDateWiseSalesReport()
                    );

                    JButton backButton =
                        new JButton("Back to Dashboard");

                    JPanel bottom = new JPanel();
                    bottom.add(dateReportButton);
                    bottom.add(backButton);

                    JPanel mainPanel =
                        new JPanel(new BorderLayout(10, 10));

                    mainPanel.add(title, BorderLayout.NORTH);
                    mainPanel.add(details, BorderLayout.CENTER);
                    mainPanel.add(bottom, BorderLayout.SOUTH);

                    backButton.addActionListener(
                        e -> showAdminDashboard(currentUsername)
                    );

                    frame.setContentPane(mainPanel);
                    frame.setTitle("MiniPOS - Sales Reports");
                    frame.setSize(800, 500);
                    frame.setLocationRelativeTo(null);
                    frame.revalidate();
                    frame.repaint();
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                frame,
                "Unable to load sales report: " + ex.getMessage()
            );
        }
    }


    // ================= DATE-WISE SALES REPORT =================

    private static void showDateWiseSalesReport() {

        String dateInput = JOptionPane.showInputDialog(
            frame,
            "Enter date (YYYY-MM-DD):\nExample: 2026-11-06"
        );

        if (dateInput == null) {
            return;
        }

        try {

            LocalDate selectedDate =
                LocalDate.parse(dateInput.trim());

            String sql = """
                SELECT
                    COUNT(*) AS total_bills,
                    COALESCE(SUM(final_total), 0) AS total_revenue
                FROM sales
                WHERE branch_id = ?
                AND DATE(sale_date) = ?
                """;

            try (
                Connection connection =
                    DatabaseConnection.getConnection();

                PreparedStatement statement =
                    connection.prepareStatement(sql)
            ) {

                statement.setInt(1, 1);
                statement.setDate(
                    2,
                    java.sql.Date.valueOf(selectedDate)
                );

                try (ResultSet rs = statement.executeQuery()) {

                    if (rs.next()) {

                        int totalBills =
                            rs.getInt("total_bills");

                        double totalRevenue =
                            rs.getDouble("total_revenue");

                        JOptionPane.showMessageDialog(
                            frame,
                            "SALES REPORT\n\n" +
                            "Date: " + selectedDate + "\n" +
                            "Total Bills: " + totalBills + "\n" +
                            String.format(
                                "Total Revenue: Rs %.2f",
                                totalRevenue
                            ),
                            "Date-wise Sales Report",
                            JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                }
            }

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                frame,
                "Invalid date format. Use YYYY-MM-DD."
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                frame,
                "Database error: " + ex.getMessage()
            );
        }
    }

    private static void showComingSoon(String feature) {

        JOptionPane.showMessageDialog(
            frame,
            feature + " will be connected in the next development steps."
        );
    }
}
