
import java.util.Scanner;

public class AdminSetup {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();

        int branchId = 1;

        System.out.println("\n========== MINIPOS ADMIN SETUP ==========");

        // Check whether an admin already exists
        if (userDAO.usernameExists("admin")) {
            System.out.println("Username 'admin' already exists.");
            System.out.println("Choose another username.");
        }

        String username;

        while (true) {
            System.out.print("Create Admin Username: ");
            username = sc.nextLine().trim();

            if (username.isEmpty()) {
                System.out.println("Username cannot be empty!");
            } else if (userDAO.usernameExists(username)) {
                System.out.println("Username already exists!");
            } else {
                break;
            }
        }

        String password;
        String confirmPassword;

        while (true) {

            System.out.print("Create Admin Password: ");
            password = sc.nextLine();

            System.out.print("Confirm Admin Password: ");
            confirmPassword = sc.nextLine();

            if (password.length() < 4) {
                System.out.println(
                        "Password must contain at least 4 characters!");
            } else if (!password.equals(confirmPassword)) {
                System.out.println("Passwords do not match!");
            } else {
                break;
            }
        }

        boolean created = userDAO.createUser(
                branchId,
                username,
                password,
                "ADMIN"
        );

        if (created) {
            System.out.println("\nAdmin account created successfully!");
            System.out.println("Username: " + username);
            System.out.println("Your password is securely hashed.");
        } else {
            System.out.println("\nAdmin account creation failed!");
        }

        sc.close();
    }
}
