
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    public boolean createUser(
            int branchId,
            String username,
            String password,
            String role) {

        String sql = """
                INSERT INTO users
                (branch_id, username, password_hash, role)
                VALUES (?, ?, ?, ?)
                """;

        String passwordHash = PasswordUtil.hashPassword(password);

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, branchId);
            statement.setString(2, username);
            statement.setString(3, passwordHash);
            statement.setString(4, role.toUpperCase());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Unable to create user!");
            e.printStackTrace();
            return false;
        }
    }

    public boolean usernameExists(String username) {

        String sql = "SELECT user_id FROM users WHERE username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet rs = statement.executeQuery()) {
                return rs.next();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean authenticate(String username, String password) {

        String sql = """
                SELECT password_hash
                FROM users
                WHERE username = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet rs = statement.executeQuery()) {

                if (rs.next()) {
                    return PasswordUtil.verifyPassword(
                            password,
                            rs.getString("password_hash")
                    );
                }
            }

        } catch (SQLException e) {
            System.out.println("Login database error!");
            e.printStackTrace();
        }

        return false;
    }

    public String getUserRole(String username) {

        String sql = "SELECT role FROM users WHERE username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, username);

            try (ResultSet rs = statement.executeQuery()) {

                if (rs.next()) {
                    return rs.getString("role");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

public void viewUsers(int branchId) {

    String sql = """
            SELECT user_id, username, role, created_at
            FROM users
            WHERE branch_id = ?
            ORDER BY user_id
            """;

    try (Connection connection = DatabaseConnection.getConnection();
         PreparedStatement statement =
                 connection.prepareStatement(sql)) {

        statement.setInt(1, branchId);

        try (ResultSet rs = statement.executeQuery()) {

            System.out.println("\n========== USER LIST ==========");

            boolean found = false;

            while (rs.next()) {
                found = true;

                System.out.println("User ID: " + rs.getInt("user_id"));
                System.out.println("Username: " + rs.getString("username"));
                System.out.println("Role: " + rs.getString("role"));
                System.out.println("Created: " + rs.getTimestamp("created_at"));
                System.out.println("-------------------------------");
            }

            if (!found) {
                System.out.println("No users found.");
            }
        }

    } catch (SQLException e) {
        System.out.println("Unable to retrieve users!");
        e.printStackTrace();
    }
}

}

