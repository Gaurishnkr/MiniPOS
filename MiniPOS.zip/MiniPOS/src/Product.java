public class Product {

    private int productId;
    private String productName;
    private double price;
    private int quantity;

    public String getProductName() {
        return productName;
    }
    public int getProductId() {
    return productId;
}
    // Constructor
    public Product(int id, String name, double price, int qty) {
        this.productId = id;
        this.productName = name;
        this.price = price;
        this.quantity = qty;
    }

    // Get price
    public double getPrice() {
        return price;
    }

    // Get available stock
    public int getQuantity() {
        return quantity;
    }

    // Update price
    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
        } else {
            System.out.println("Invalid price!");
        }
    }

    // Calculate bill and reduce stock
    public double calculateTotal(int quantityPurchased) {

        if (quantityPurchased <= 0) {
            System.out.println("Invalid purchase quantity!");
            return 0;
        }

        if (quantityPurchased > quantity) {
            System.out.println("Insufficient stock!");
            return 0;
        }

        quantity = quantity - quantityPurchased;

        System.out.println("Purchase successful!");

        return price * quantityPurchased;
    }

    // Display product details
    public void displayProduct() {
        System.out.println("Product ID: " + productId);
        System.out.println("Product Name: " + productName);
        System.out.println("Price: " + price);
        System.out.println("Quantity: " + quantity);
    }
}