
import java.util.List;

public class LoadProductsTest {

    public static void main(String[] args) {

        ProductDAO productDAO = new ProductDAO();

        int branchId = 1;

        List<Product> products = productDAO.getProducts(branchId);

        System.out.println("\n====== PRODUCTS FROM DATABASE ======");

        for (Product product : products) {

            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Product Name: " + product.getProductName());
            System.out.println("Price: Rs " + product.getPrice());
            System.out.println("Available Stock: " + product.getQuantity());

            System.out.println("--------------------------------");
        }

        System.out.println("Total Products: " + products.size());
    }
}
