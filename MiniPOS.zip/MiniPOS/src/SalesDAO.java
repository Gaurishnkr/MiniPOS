
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SalesDAO {

    public boolean saveSale(
            int branchId,
            String billNumber,
            double subtotal,
            double discount,
            double gst,
            double finalTotal,
            double cashReceived,
            double changeReturned,
            List<Product> products,
            List<Integer> quantities) {

        String saleSQL = """
                INSERT INTO sales
                (branch_id, bill_number, subtotal, discount, gst,
                 final_total, cash_received, change_returned)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        String itemSQL = """
                INSERT INTO sale_items
                (sale_id, product_id, quantity, unit_price, line_total)
                VALUES (?, ?, ?, ?, ?)
                """;

        String stockSQL = """
                UPDATE products
                SET quantity = quantity - ?
                WHERE product_id = ?
                AND branch_id = ?
                AND quantity >= ?
                """;

        try (Connection connection = DatabaseConnection.getConnection()) {

            connection.setAutoCommit(false);

            try {
                int saleId;

                // Save main bill
                try (PreparedStatement saleStatement =
                             connection.prepareStatement(
                                     saleSQL,
                                     PreparedStatement.RETURN_GENERATED_KEYS)) {

                    saleStatement.setInt(1, branchId);
                    saleStatement.setString(2, billNumber);
                    saleStatement.setDouble(3, subtotal);
                    saleStatement.setDouble(4, discount);
                    saleStatement.setDouble(5, gst);
                    saleStatement.setDouble(6, finalTotal);
                    saleStatement.setDouble(7, cashReceived);
                    saleStatement.setDouble(8, changeReturned);

                    saleStatement.executeUpdate();

                    try (ResultSet keys = saleStatement.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Sale ID was not generated.");
                        }
                        saleId = keys.getInt(1);
                    }
                }

                // Save bill items and update stock
                try (PreparedStatement itemStatement =
                             connection.prepareStatement(itemSQL);
                     PreparedStatement stockStatement =
                             connection.prepareStatement(stockSQL)) {

                    for (int i = 0; i < products.size(); i++) {

                        Product product = products.get(i);
                        int quantity = quantities.get(i);

                        itemStatement.setInt(1, saleId);
                        itemStatement.setInt(2, product.getProductId());
                        itemStatement.setInt(3, quantity);
                        itemStatement.setDouble(4, product.getPrice());
                        itemStatement.setDouble(
                                5, product.getPrice() * quantity);

                        itemStatement.executeUpdate();

                        stockStatement.setInt(1, quantity);
                        stockStatement.setInt(2, product.getProductId());
                        stockStatement.setInt(3, branchId);
                        stockStatement.setInt(4, quantity);

                        int updated = stockStatement.executeUpdate();

                        if (updated == 0) {
                            throw new SQLException(
                                    "Insufficient stock for "
                                            + product.getProductName());
                        }
                    }
                }

                connection.commit();
                return true;

            } catch (SQLException e) {

                connection.rollback();
                System.out.println("Sale saving failed. Changes rolled back.");
                e.printStackTrace();

                return false;

            } finally {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {

            System.out.println("Database error while saving sale!");
            e.printStackTrace();

            return false;
        }
    }

    public void viewSalesHistory(int branchId) {

    String sql = """
            SELECT sale_id, bill_number, final_total, sale_date
            FROM sales
            WHERE branch_id = ?
            ORDER BY sale_id DESC
            """;

    try (Connection connection = DatabaseConnection.getConnection();
         PreparedStatement statement = connection.prepareStatement(sql)) {

        statement.setInt(1, branchId);

        try (ResultSet rs = statement.executeQuery()) {

            System.out.println("\n========== DATABASE SALES HISTORY ==========");

            while (rs.next()) {
                System.out.println(
                        "Sale ID: " + rs.getInt("sale_id")
                        + " | Bill: " + rs.getString("bill_number")
                        + " | Total: Rs " + rs.getDouble("final_total")
                        + " | Date: " + rs.getTimestamp("sale_date")
                );
            }

            System.out.println("============================================");

        }

    } catch (SQLException e) {
        System.out.println("Unable to load sales history!");
        e.printStackTrace();
    }
}


public void viewDailySalesReport(int branchId) {

    String sql = """
            SELECT
                COUNT(*) AS total_bills,
                COALESCE(SUM(final_total), 0) AS total_sales,
                COALESCE(SUM(discount), 0) AS total_discounts,
                COALESCE(SUM(gst), 0) AS total_gst
            FROM sales
            WHERE branch_id = ?
            AND DATE(sale_date) = (
                SELECT MAX(DATE(sale_date))
                FROM sales
                WHERE branch_id = ?
)
            """;

    try (Connection connection = DatabaseConnection.getConnection();
         PreparedStatement statement = connection.prepareStatement(sql)) {

        statement.setInt(1, branchId);
        statement.setInt(2, branchId);

        try (ResultSet rs = statement.executeQuery()) {

            if (rs.next()) {
                System.out.println("\n========== DAILY SALES REPORT ==========");
                System.out.println("Total Bills: " + rs.getInt("total_bills"));
                System.out.printf("Total Sales: Rs %.2f%n",
                        rs.getDouble("total_sales"));
                System.out.printf("Total Discounts: Rs %.2f%n",
                        rs.getDouble("total_discounts"));
                System.out.printf("Total GST Collected: Rs %.2f%n",
                        rs.getDouble("total_gst"));
                System.out.println("========================================");
            }
        }

    } catch (SQLException e) {
        System.out.println("Unable to load daily sales report!");
        e.printStackTrace();
    }
}


public String generateBillNumber() {

    String sql = """
            SELECT COALESCE(MAX(sale_id), 0) + 1 AS next_number
            FROM sales
            """;

    try (Connection connection = DatabaseConnection.getConnection();
         PreparedStatement statement = connection.prepareStatement(sql);
         ResultSet rs = statement.executeQuery()) {

        if (rs.next()) {
            int nextNumber = rs.getInt("next_number");
            return String.format("BILL-%03d", nextNumber);
        }

    } catch (SQLException e) {
        System.out.println("Unable to generate bill number!");
        e.printStackTrace();
    }

    return null;
}

}
