import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter; 
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        
        ArrayList<String> receiptItems = new ArrayList<>();

        Scanner sc = new Scanner(System.in);

        // Create products
        Product p1 = new Product(101, "Keyboard", 900, 5);
        Product p2 = new Product(102, "Mouse", 400, 10);
        Product p3 = new Product(103, "Monitor", 8000, 3);

        double grandTotal = 0;
        int billNumber = 1;
        String choice;

        System.out.println("===== MINI POS BILLING SYSTEM =====");

        while (true) {

            System.out.print("\nEnter Product ID: ");
            int productId = sc.nextInt();

            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();

            Product selectedProduct = null;

            if (productId == 101) {
                selectedProduct = p1;
            } else if (productId == 102) {
                selectedProduct = p2;
            } else if (productId == 103) {
                selectedProduct = p3;
            }

            if (selectedProduct != null) {

                double total = selectedProduct.calculateTotal(quantity);

                if (total > 0) {
                    grandTotal += total;
                    String item = String.format("%-15s %5d %10.2f %10.2f",
        selectedProduct.getProductName(),
        quantity,
        selectedProduct.getPrice(),
        total);

receiptItems.add(item);

                    System.out.println("\nProduct: "
                            + selectedProduct.getProductName());
                    System.out.println("Price: "
                            + selectedProduct.getPrice());
                    System.out.println("Quantity: " + quantity);
                    System.out.println("Amount: " + total);
                    System.out.println("Remaining Stock: "
                            + selectedProduct.getQuantity());
                }

            } else {
                System.out.println("Invalid Product ID!");
            }

            System.out.print("\nAdd another product? (yes/no): ");
            choice = sc.next();

            if (choice.equalsIgnoreCase("no")) {
                break;
            }
        }

        System.out.println("\n========== MINI POS RECEIPT ==========");

System.out.println("Bill Number: BILL-" + String.format("%03d", billNumber));

System.out.println("Date & Time: " + now.format(formatter));

System.out.println("----------------------------------------------");

        System.out.println("----------------------------------------------");
System.out.printf("%-15s %5s %10s %10s%n",
        "Product", "Qty", "Price", "Amount");
System.out.println("----------------------------------------------");

for (String item : receiptItems) {
    System.out.println(item);
}

System.out.println("----------------------------------------------");

System.out.println("--------------------------------------");
System.out.println("Grand Total: Rs" + grandTotal);
System.out.println("======================================");

        System.out.println("\n===== REMAINING STOCK =====");
        p1.displayProduct();
        p2.displayProduct();
        p3.displayProduct();

        sc.close();
    }
}
