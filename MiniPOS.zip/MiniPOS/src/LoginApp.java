
import java.util.Scanner;

public class LoginApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();

        System.out.println("\n========== MINIPOS LOGIN ==========");

        System.out.print("Username: ");
        String username = sc.nextLine().trim();

        System.out.print("Password: ");
        String password = sc.nextLine();

        boolean authenticated = userDAO.authenticate(username, password);

        if (authenticated) {

            String role = userDAO.getUserRole(username);

            System.out.println("\nLogin successful!");
            System.out.println("Welcome, " + username);
            System.out.println("Role: " + role);

            if ("ADMIN".equalsIgnoreCase(role)) {

                SalesDAO salesDAO = new SalesDAO();
                int choice;

                do {
                    System.out.println("\n========== ADMIN DASHBOARD ==========");
                    System.out.println("1. Manage Products");
                    System.out.println("2. Manage Stock");
                    System.out.println("3. Manage Users");
                    System.out.println("4. View Sales History");
                    System.out.println("5. View Sales Reports");
                    System.out.println("6. Logout");
                    System.out.println("=====================================");

                    choice = readChoice(sc);

                    switch (choice) {

                        case 1:
                            ProductManagementApp.open(sc);
                            break;

                        case 2:
                            System.out.println(
                                "Stock management is available under Manage Products."
                            );
                            break;

                        case 3:
                            UserManagementApp.open(sc);
                            break;

                        case 4:
                            salesDAO.viewSalesHistory(1);
                            break;

                        case 5:
                            salesDAO.viewDailySalesReport(1);
                            break;

                        case 6:
                            System.out.println("Logging out...");
                            break;

                        default:
                            System.out.println("Invalid choice!");
                    }

                } while (choice != 6);

            } else if ("CASHIER".equalsIgnoreCase(role)) {

                SalesDAO salesDAO = new SalesDAO();
                int choice;

                do {
                    System.out.println("\n========== CASHIER DASHBOARD ==========");
                    System.out.println("1. Create Bill");
                    System.out.println("2. View Sales History");
                    System.out.println("3. Logout");
                    System.out.println("=======================================");

                    choice = readChoice(sc);

                    switch (choice) {

                        case 1:
                            Main.open(sc);
                            break;

                        case 2:
                            salesDAO.viewSalesHistory(1);
                            break;

                        case 3:
                            System.out.println("Logging out...");
                            break;

                        default:
                            System.out.println("Invalid choice!");
                    }

                } while (choice != 3);

            } else {
                System.out.println("Invalid user role!");
            }

        } else {
            System.out.println("\nInvalid username or password!");
        }

        sc.close();
    }

    private static int readChoice(Scanner sc) {

        System.out.print("Enter your choice: ");

        String input = sc.nextLine().trim();

        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
