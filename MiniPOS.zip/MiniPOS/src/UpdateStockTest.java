public class UpdateStockTest {

    public static void main(String[] args) {

        ProductDAO productDAO = new ProductDAO();

        // Update Keyboard stock in Main Branch
        boolean result = productDAO.updateStock(
                1,  // Product ID
                1,  // Branch ID
                25  // New stock quantity
        );

        if (result) {
            System.out.println("Stock updated successfully!");
        } else {
            System.out.println("Stock update failed!");
        }
    }
}