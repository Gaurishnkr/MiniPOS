
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    // 1. Add Product
    public boolean addProduct(
            int branchId,
            String productName,
            double price,
            int quantity) {

        String sql = """
                INSERT INTO products
                (branch_id, product_name, price, quantity)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, branchId);
            statement.setString(2, productName);
            statement.setDouble(3, price);
            statement.setInt(4, quantity);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error adding product!");
            e.printStackTrace();
            return false;
        }
    }

    // 2. View Products
    public void viewProducts(int branchId) {

        String sql = "SELECT * FROM products WHERE branch_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, branchId);

            try (ResultSet rs = statement.executeQuery()) {

                System.out.println("\n========== PRODUCT LIST ==========");

                System.out.printf(
                        "%-10s %-20s %-12s %-10s%n",
                        "ID", "PRODUCT", "PRICE", "STOCK"
                );

                while (rs.next()) {
                    System.out.printf(
                            "%-10d %-20s %-12.2f %-10d%n",
                            rs.getInt("product_id"),
                            rs.getString("product_name"),
                            rs.getDouble("price"),
                            rs.getInt("quantity")
                    );
                }

                System.out.println("==================================");
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving products!");
            e.printStackTrace();
        }
    }

    // 3. Update Product Stock
    public boolean updateStock(
            int productId,
            int branchId,
            int newQuantity) {

        String sql = """
                UPDATE products
                SET quantity = ?
                WHERE product_id = ?
                AND branch_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, newQuantity);
            statement.setInt(2, productId);
            statement.setInt(3, branchId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error updating stock!");
            e.printStackTrace();
            return false;
        }
    }

    // 4. Delete Product
    public boolean deleteProduct(int productId, int branchId) {

        String sql = """
                DELETE FROM products
                WHERE product_id = ?
                AND branch_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, productId);
            statement.setInt(2, branchId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error deleting product!");
            System.out.println("The product may have existing sales records.");
            e.printStackTrace();
            return false;
        }
    }

    // 5. Get Products from Database
    public List<Product> getProducts(int branchId) {

        List<Product> products = new ArrayList<>();

        String sql = """
                SELECT product_id, product_name, price, quantity
                FROM products
                WHERE branch_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, branchId);

            try (ResultSet rs = statement.executeQuery()) {

                while (rs.next()) {

                    Product product = new Product(
                            rs.getInt("product_id"),
                            rs.getString("product_name"),
                            rs.getDouble("price"),
                            rs.getInt("quantity")
                    );

                    products.add(product);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error loading products!");
            e.printStackTrace();
        }

        return products;
    }
}
